import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
const ManagerList = () => {
  // State to store staff information
  const [manager, setManager] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchManager();
  }, []);



  const fetchManager = async () => {
    try {
      const response = await axios.get('http://localhost:7070/hms/managers'); // Change the API endpoint as per your backend
      setManager(response.data);
    } catch (error) {
      console.error('Error fetching manager:', error);
    }
  };
 
  


  // Filter staff based on search query
  const filteredManager = manager.filter((employee) =>
    `${employee.id} ${employee.firstName} ${employee.lastName}`.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div style={styles.adminPage}>
      <div style={styles.adminHeader}>
        <h1>Manager List</h1>
        <button style={{ ...styles.button, padding: '2px 4px 2px 4px' }} ><Link to="/home">Logout</Link></button>
      </div>
      <div style={styles.adminActions}>
        <button style={{ ...styles.button, marginRight: '150px', padding: '10px 20px 10px 20px' }}><Link to="/addmanager">Add New</Link></button>
       
        <input
          type="text"
          placeholder="Search Manager"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>
      <div style={styles.managerList}>
        <table style={styles.table}>
          <thead>
            <tr>
               <th>Manager Id</th> 
              <th>First Name</th>
              <th>Last Name</th>
              <th>Salary</th>
              <th>DOB</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Password</th>
              <th>Hire Date</th>
         
            </tr>
          </thead>
          <tbody>
            {filteredManager.map((employee) => (
              <tr key={employee.id}>
                 <td>{employee.id}</td> 
                <td>{employee.firstName}</td>
                <td>{employee.lastName}</td>
                <td>{employee.salary}</td>
                <td>{employee.dob}</td>
                <td>{employee.phone}</td>
                <td>{employee.email}</td>
                <td>{employee.password}</td>
                <td>{employee.hireDate}</td>
               
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const styles = {
  adminPage: {
    maxWidth: '800px',
    margin: '0 auto',
    padding: '20px',
    fontFamily: 'Arial, sans-serif',
  },
  adminHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '20px',
  },
  adminActions: {
    display: 'inline-flex',
    marginBottom: '20px',
  },
  staffList: {
    maxWidth: '100%',
    overflowX: 'auto',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    border: '1px solid #ddd',
  },
  th: {
    backgroundColor: '#ffffff',
    boxShadow: '0px 0px 9px 0px rgba(0,0,0,0.1)',
    fontWeight: 'bold',
    border: '1px solid #ddd',
    padding: '10px',
    textAlign: 'left',
  },
  td: {
    border: 'none',
    borderBottom: '1px solid #ddd',
    padding: '10px',
  },
  row: {
    transition: 'background-color 0.3s ease',
  },
  button: {
    marginRight: '10px',
    padding: '10px 20px',
    backgroundColor: '#000000',
    color: '#fff',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    transition: 'background-color 0.3s ease',
  },
  
};

export default ManagerList;