import React from 'react';
import optimizedBackgroundImage from '../images/abcd.jpg';

const containerStyle = {
  backgroundImage: `url(${optimizedBackgroundImage})`,
  backgroundSize: 'contain', // You can adjust this value to 'cover', 'contain', or specific dimensions like '100% 100%'
  backgroundRepeat: 'no-repeat',
  height: '100vh',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'right',
  justifyContent: 'center',
  color: 'darkblue',
  textAlign: 'center', // Align the text in the center
  textShadow: '2px 2px 4px rgba(255, 255, 255, 0.8)', // Optional text shadow
  fontSize: '50px', // Adjust the font size as needed
  fontWeight: 'bold', // Optional font weight
};

export default function Logout() {
  return (
    <div style={containerStyle}>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Thank You!!!!!!!!!!!!!!!!!!!!!!
    </div>
  );
}