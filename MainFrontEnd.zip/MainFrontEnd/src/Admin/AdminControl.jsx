import React from 'react'
import AdminControlNav from './AdminControlNav';


function AdminControl() {
    return (

        <div className='container mt-4'>
            <div className='row'>
                <div className='col-md-4'>
                    <AdminControlNav />
                </div>
                <div className='col-md-8'>

                </div>
            </div>

        </div>


    )
}

export default AdminControl
